package br.edu.moeda.dollarService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DollarServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
