package br.edu.moeda.dollarService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DollarServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DollarServiceApplication.class, args);
	}

}
